#include "sff.h"

void dgemm_(char * a, char * b, INT_T * c, INT_T * d, INT_T * e, REAL_T * f,
            REAL_T * g, INT_T * h, REAL_T * i, INT_T * j, REAL_T * k, REAL_T * l,
            INT_T * m)
{
}

double epbsa(void * pbopt,void * prm,double x,double grad,void * enb,void * eel,void * esurf,void * evdwnp,int iter,int i)
{
   return (0);
}

void pboptinit( void * pbopt)
{
}

