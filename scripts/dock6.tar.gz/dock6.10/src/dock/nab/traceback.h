int	rt_errormsg( int, char [] );
int	rt_errormsg_s( int, char [], char [] );
int	rt_errormsg_2s( int, char [], char [], char [] );
int	rt_errormsg_d( int, char [], int );
