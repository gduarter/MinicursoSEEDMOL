// definition of the DOCK version.

#ifndef VERSION_H
#define VERSION_H

const char *const DOCK_VERSION="DOCK v6.10" ;

const char *const DOCK_RELEASE_DATE="January 2023" ;

#endif  // VERSION_H
