#define NAB_DOUBLE_PRECISION 1
#define REAL_T	double
