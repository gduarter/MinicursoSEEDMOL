      common /files/ input,output,qin,qout,punch,espot,qwts,esout,
     .               owrite
      character*80 input,output,qin,qout,punch,espot,qwts,esout
      character owrite
