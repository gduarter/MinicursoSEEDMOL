/*                                                                    */
/*                        Copyright UCSF, 1997                        */
/*                                                                    */

/*
Written by Todd Ewing
10/95
*/

void get_parameters
(
  DOCK *,
  ORIENT *,
  SCORE *,
  LABEL *
);

int process_commands (DOCK *, int argc, char *argv[]);

