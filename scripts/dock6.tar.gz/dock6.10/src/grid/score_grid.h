/*                                                                    */
/*                        Copyright UCSF, 1997                        */
/*                                                                    */

/*
Written by Todd Ewing
9/96 te
*/

void make_grids
(
  SCORE_GRID *,
  SCORE_BUMP *,
  SCORE_CONTACT *,
  SCORE_CHEMICAL *,
  SCORE_ENERGY *,
  LABEL *,
  MOLECULE *
);

