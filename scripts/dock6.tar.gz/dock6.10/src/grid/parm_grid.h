/*                                                                    */
/*                        Copyright UCSF, 1997                        */
/*                                                                    */

/*
Written by Todd Ewing
10/95
*/

int get_parameters
(
  GRID *,
  SCORE_GRID *,
  SCORE_BUMP *,
  SCORE_CONTACT *,
  SCORE_CHEMICAL *,
  SCORE_ENERGY *,
  LABEL *
);

int process_commands (int argc, char *argv[]);

